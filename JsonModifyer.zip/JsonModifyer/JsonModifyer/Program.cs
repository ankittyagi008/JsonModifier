﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace JsonModifyer
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();
            p.SerializeAsJson();
        }

        private DataTable GetExcelData()
        {

            DataTable dt = new DataTable();
            dt.Clear();
            dt.Columns.Add("ParentNode");
            dt.Columns.Add("Child");

            DataRow row1 =
            dt.Rows.Add("Customer", "Name");
            dt.Rows.Add("CustomerAddess", "Address1");
            return dt;
        }

        private Customer PopulateCustomer()
        {
            Customer customer = new Customer
            {
                Name = "Ankit",
                Age = 31,
                CustomerAddess = new Address
                {
                    Address1 = "Address1",
                    Address2 = "Address2",
                    State = "UP",
                    Pin = "201206"
                }
            };

            return customer;

        }

        private string SerializeAsJson()
        {
            Customer customer = PopulateCustomer();
            FieldInfo[] fields = typeof(Customer).GetFields(BindingFlags.);
            foreach (var field in fields)
            {
                // do something
            }

            PropertyInfo[] property_infos = typeof(Customer).GetProperties();
            foreach (PropertyInfo info in property_infos)
            {
                // Do something...
            }

            MemberInfo[] Member_infos = typeof(Customer).GetMembers();
            foreach (MemberInfo info in Member_infos)
            {
                // Do something...
            }       


            Type[] nestedTypes = typeof(Customer).GetNestedTypes();
            foreach (Type t in nestedTypes)
            {
                Console.WriteLine(t.Name);
            }
            return "";
        }
    }

    public class Customer
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public Address CustomerAddess = new Address();
    }

    public class Address
    {
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Pin { get; set; }
        public string State { get; set; }
    }


}
